select now();
